#ifndef AI_HOMEWORK_INCLUDER_H
#define AI_HOMEWORK_INCLUDER_H

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <cstring>
#include <vector>
#include <queue>

using namespace std;

#endif //AI_HOMEWORK_INCLUDER_H
